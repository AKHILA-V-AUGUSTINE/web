<?php
include "config.php";
$sql = " SELECT * FROM `register` " ;
$result=$conn->query($sql);
?>




<html>
<head>
<title>Person data</title>
</head>

<link rel="stylesheet" href="stylelog.css">
<body>

	<div>
		<img src="logobook.jpg" class="logoreg">
	<form action="" method="post">
	<center>
	<table class="loginbox">
<?php
if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{
?>
		<tr>
			<td>
				id
			</td>
			<td><?php echo $row['id'];?></td>
		</tr>
			<td>Name:</td>
			<td>
				<input type="text" name="username" placeholder="Enter the name" value="<?php echo $row['username'];?>">
			</td>
		</tr>
		<tr>
			<td>Password: </td>
			<td>
				<input type="Password"name="password" placeholder="Enter the Password" value="<?php echo $row['password'];?>">
			</td>
        </tr>
         <tr>
        	<td>Confirm Password:</td>
        	<td>
        		<input type="Password" id="password1" placeholder="Enter the Confirm password" name="confpassword" value="<?php echo $row['confpassword'];?>">
        	</td>
        </tr>
        <tr>
			<td>
				Gender:
			</td>
		</tr>
		<tr>
		<td></td>
			<td>
			<input type="radio" name="gender" value="<?php echo $row['gender'];?>">Male
            </td> 
            </tr>
            <tr> 
            <td></td>  
            <td>
			<input type="radio" name="gender" value="<?php echo $row['gender'];?>">Female
			</td>
		</tr>
		<tr>
			<td>Email:</td>
			<td>
				<input type="email" placeholder="Enter the email" name="email" value="<?php echo $row['email'];?>">
			</td>
		</tr>
		<tr>
			<td>Phone.no:</td>
			<td>
			<input type="text" placeholder="Enter the phone number"name="phone_n" value="<?php echo $row['phone_n'];?>">
		</td>
		</tr>
		<tr>
			<td>
			<a href="delete.php?id=<?php echo $row['id'];?>"><button type="button">Delete</button>
			
			</td>
			<td>
				<a href="update.php?id="<?php echo $row['id'];?>"> <button type="button">Edit</button>
					
					
				</a>
		    </td>
		    <td>
		    	
		    		 <button type="button">Confirm</button>
		    </td>
		</tr>
	
	<?php
	}
}
?>

		</table>
	</center>
	</form>
</div>
</body>
</html>