<?php
include  "config.php";
if(isset($_POST['submit']))
{
$username=$_POST['username'];
$password=$_POST['password'];
$confpassword=$_POST['confpassword'];
$gender=$_POST['gender'];
$email=$_POST['email'];
$phone_n=$_POST['phone_n'];
$sql = "INSERT INTO `register`(`username`,`password`,`confpassword`, `gender`,`email`,`phone_n`) VALUES ( '$username', '$password', '$confpassword','$gender','$email','$phone_n')";
$result=$conn->query($sql);
if($result==TRUE)
{
	header('location:dataregistration.php');
	
	
}
else
{
echo '<script> 	alert( "Error".$sql."<br>".$conn->error)</script>';
}
$conn->close();
}
?>

<html>
<head>
<title>Registration</title>
</head>
<link rel="stylesheet" href="stylelog.css">
<body>
	<script type="text/javascript" src="regvalidation.js">
		
	</script>
	<div>
		<img src="logobook.jpg" class="logoreg">
	<form action="" method="post">
	<center>
	<table class="loginbox">
		<tr>
			<td>Name:</td>
			<td>
				<input type="text" id="username" placeholder="Enter the name" autocomplete="off" name="username">
			</td>
		</tr>
		<tr>
			<td>Password: </td>
			<td>
				<input type="Password" id="password" placeholder="Enter the Password" name="password">
			</td>
        </tr>
        <tr>
        	<td>Confirm Password:</td>
        	<td>
        		<input type="Password" id="confpassword" placeholder="Enter the Confirm password" name="confpassword">
        	</td>
        </tr>
        <tr>
			<td>
				Gender:
			</td>
		</tr>
		<tr>
		<td></td>
			<td>
			<input type="radio" name="gender" id="gender">Male
            </td> 
            </tr>
            <tr> 
            <td></td>  
            <td>
			<input type="radio" name="gender"id="gender">Female
			</td>
		</tr>
		<tr>
			<td>Email:</td>
			<td>
				<input type="email" placeholder="Enter the email" name="email">
			</td>
		</tr>
		<tr>
			<td>Phone.no:</td>
			<td>
			<input type="text" placeholder="Enter the phone number" name="phone_n">
		</td>
		</tr>
		<tr>
			<td></td>
			<td>
			<input type="submit" value="submit" name="submit"onclick="validation()" >
		    </td>
		</tr>
		</table>
	</center>
	</form>
</div>
</body>
</html>