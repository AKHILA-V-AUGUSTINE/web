<?php 

include "config.php";

    if (isset($_POST['edit'])){

        $username = $_POST['username'];

        $id = $_POST['id'];

        $password = $_POST['password'];
        $confpassword = $_POST['confpassword'];
        $gender = $_POST['gender']; 

        $email = $_POST['email'];

        
        $phone_n=$_POST['phone_n'];

        $sql = "UPDATE `register` SET `username`='$username',`password`='$password',`confpassword`='$confpassword',`gender`='$gender',`email`='$email',`phone_n`='$phone_n' WHERE `id`='$id'"; 

        $result = $conn->query($sql); 

        if ($result == TRUE) {

            echo "Record updated successfully.";

        }else{

            echo "Error:" . $sql . "<br>" . $conn->error;

        }

    } 

if (isset($_GET['id'])) {

    $id = $_GET['id']; 

    $sql = "SELECT * FROM `register` WHERE `id`='$id'";

    $result = $conn->query($sql); 

}

    if ($result->num_rows > 0) {        

        while ($row = $result->fetch_assoc()) {

            $username = $row['username'];
            $password  = $row['password'];
            $confpassword = $row['confpassword'];
            $gender = $row['gender'];
            $email = $row['email'];
            $phone_n= $row['phone_n'];
            $id = $row['id'];

       }
       ?>

    <?php
}

    else{ 

        header('Location: dataupdate.php');

       } 



?> 
    


