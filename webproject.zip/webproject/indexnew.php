<html>
<head><title>index</title></head>
<link rel="stylesheet" href="style.css">
<body>
<div class="banner">
	<div class="navbar">
		<img src="logobook.jpg" class="logo">
		<ul>
			<li><a href="home.html">About</a></li>
			<li><a href="login.html">Sign in</a></li>
			<li><a href="registration.php">Register</a></li>
		</ul>
	</div>
<div class="content">
	<h1>READING BOOKS</h1>
	<p>change your habit,change your life</p>
	<div>
		<a href="login.html">
		<button type="button"><span></span>LOGIN</button></a>
		<a href="registration.php">
		<button type="button"><span></span>REGISTER</button></a>
	</div>
</div>
</div>
	
</body>
</html>