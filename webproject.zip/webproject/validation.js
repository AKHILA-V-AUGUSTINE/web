

		function logvalidation()
		{
			var name=document.getElementById("username").value;
			var pwd=document.getElementById("password").value;
			if(name=="")
			{
				alert("Enter username");
			}
			else if(pwd=="")
			{
				alert("Enter password");
			}
		    else
			{
				alert("Sucessfully login");
				window.location.href="home.html";

			}
		}
	