function validation() {
			var name=document.getElementById("username").value;
			var pwd=document.getElementById("password").value;
			var cpwd=document.getElementById("confpassword1").value;
			if(name=="")
			{
				alert("Please enter the username");
			}
			else if(pwd=="")
			{
				alert("Please enter the password");
			}
			else if(cpwd=="")
			{
				alert("Please enter the confirm password");
			}
			else if(cpwd!=pwd)
			{ 
				alert("Password and confirm password must be same");
			}
			else
			{
				alert("Sucessfully Submitted");
				window.location.href="home.html";

			}
		}