

<html>
<head>
<title>Person data</title>
</head>

<link rel="stylesheet" href="stylelog.css">
<body>

    <div>
        <img src="logobook.jpg" class="logoreg">
    <form action="update.php" method="post">
    <center>
    <table class="loginbox">
       <tr
             <input type="hidden" name="id" value="<?php echo $id; ?>">
        </tr>
            <td>Name:</td>
            <td>
                <input type="text" name="username" placeholder="Enter the name" value="<?php echo $username;?>">
            </td>

        <tr>
            <td>Password: </td>
            <td>
                <input type="Password"name="password" placeholder="Enter the Password" value="<?php echo $password;?>">
            </td>
        </tr>
         <tr>
            <td>Confirm Password:</td>
            <td>
                <input type="Password" id="confpassword" placeholder="Enter the Confirm password" name="confpassword" value="<?php echo $confpassword;?>">
            </td>
        </tr>
        <tr>
            <td>
                Gender:
            </td>
        </tr>
        <tr>
        <td></td>
            <td>
            <input type="radio" name="gender" value="<?php echo $gender;?>">Male
            </td> 
            </tr>
            <tr> 
            <td></td>  
            <td>
            <input type="radio" name="gender" value="<?php echo $gender;?>">Female
            </td>
        </tr>
        <tr>
            <td>Email:</td>
            <td>
                <input type="email" placeholder="Enter the email" name="email" value="<?php echo $email;?>">
            </td>
        </tr>
        <tr>
            <td>Phone.no:</td>
            <td>
            <input type="text" placeholder="Enter the phone number"name="phone_n" value="<?php echo $phone_n;?>">
        </td>
        </tr>
        <tr>
            <td>
                 <button type="button">Update</button>
                    
                    
                </a>
            </td>
            <td>
                
                     <button type="button">Confirm</button>
            </td>
        </tr>
    </table>
</center>
</form>
</body>
</html>
        
 