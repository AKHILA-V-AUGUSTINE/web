    <html> 
	<head> 
	
	<title>Login Form </title> 
	<link rel="stylesheet" type="text/css" href="stylelog.css"> 

	<body> 
	<script type="text/javascript" src="validation.js"> 

	
	</script> 
	<div class="loginbox"> 
	<img src="logobook.jpg" class="logo"> 

	
	<h1>Login Here</h1> 
	<form > 
	<p>Username</p> 
	<input type="text"id="username" name="username"placeholder="Enter the name" autocomplete="off"> 
	<p>Password</p> 
	<input type="Password" id="password" name="password"placeholder="Enter the Password"><br><br> 
	<input type="submit" value="Sign in" onclick="logvalidation()"><br> 
	<a href="registration.php">Don't have account</a> 

	</form> 
	
	
	</div> 
	</body> 
	</head> 
	</html>
